﻿using System;

namespace PCPartsSuperStore
{
    public partial class Master : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

    }
}