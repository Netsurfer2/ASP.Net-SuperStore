﻿using System;

namespace PCPartsSuperStore.userManagement
{
    public partial class MakeUserLogIn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

    }
}